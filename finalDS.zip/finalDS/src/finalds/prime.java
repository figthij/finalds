/*
project name: FinalDS
program:prime
Author: Erik Bailey
Date: Dec 7 2020
Synoposis: 
takes prime numbers out of order queue 
*/
package finalds;
import java.util.Queue;
public class prime {
    public int prime(Queue<Integer> order){
        int prime=0;
        prime=order.remove();
        return prime;
    }
}
