/*
project name: Finalds
program: compare2
Author: Erik Bailey
Date: Dec 11, 2020
Synoposis: 
compares two numbers in the array to see which is bigger
*/
package finalds;
public class compare2 {
    public int comp(int[] a, int fir, int sec){
        if(a[fir]>a[sec]){
            return 1;
        }
        return 0;
    }
}