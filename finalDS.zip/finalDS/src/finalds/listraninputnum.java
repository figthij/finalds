/*
project name: FinalDS
program:raninputnum
Author: Erik Bailey
Date: Nov 4 2020
Synoposis: 
makes random numbers and puts them in array 
*/
package finalds;
import java.util.Random;
public class listraninputnum {
    public void raninputnum(int[] value,int i){
        Random rnum = new Random();
        value[i]=rnum.nextInt(1000);
    }
}
