/*
project name: FinalDS
program:remove
Author: Erik Bailey
Date: Dec 7, 2020
Synoposis: 
removes values from array
*/
package finalds;
public class recurremove {
    public int[] rem(int[] yr, int start){
        recurmultiply m = new recurmultiply();
        int r=start;//will be changed based on another class
        int times=1;
        int out =0;//number of zeros in array
        while(r<1001){
            times=times+1;
            for(int i=0;i<yr.length;i++){
                if((yr[i]==r)&&(yr[i]!=start)){
                    out=out+1;
                    yr[i]=0;
                }
            }
            r=m.out(start, times);
        }
        recurendzero ez =new recurendzero();
        ez.back(yr,out);
        return yr;
    }
}
