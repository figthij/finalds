/*
project name: FinalDS
program:linkedlist
Author: Erik Bailey
Date: Dec 7, 2020
Synoposis: makes a linked list with random numbers
*/
package finalds;
import java.awt.AWTException;
import java.awt.Robot;
import java.util.Scanner;
public class linkedlist {
    public void main() throws AWTException {
        Scanner sc = new Scanner(System.in);
        String s="";     
        String title="linked list";
        OutputClass test = new OutputClass();
        String exit="EXIT";
        while(s.matches(exit)==false){
            test.printScreen(title);
            listraninputnum ran=new listraninputnum();
            listlargest lar = new listlargest();
            listsearch sea=new listsearch();
            int size=1000000;
            int half=10000;
            int[] value = new int[size];
            int i =0;
            int large;
            while(i<size){
                ran.raninputnum(value, i);
                i=i+1;
            }
            large=lar.largestinlist(value, size);//large is the highest value in the list
            int large1=large +1;//large1 means large+1
            int[][] a = new int[large1][half];
            int num=large;
            while(num!=-1){
                int[] a1=new int[half];
                a1=sea.recSearch(value,0,size-1,num,a1,0);
                System.arraycopy(a1, 0, a[num], 0, a1.length); //if(a1[j]!=-1){
                num=num-1;
            }
            System.out.println("The first 10 values of " +large+" are: ");
            for(int w = 0; w<10;w++){
                if(a[large][w]!=-1){
                    System.out.print(a[large][w]+" ");
            }
        }
        System.out.println();
        System.out.println("Type EXIT to go back");
        System.out.println("Type anything else to get another combination");
        s=sc.next();
        Robot rob=new Robot();
        refresh.clear(rob,500);
        }
    }
}
