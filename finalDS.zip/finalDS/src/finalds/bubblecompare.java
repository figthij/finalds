/*
project name: finalds
program: bubblecompare
Author: Erik Bailey
Date: Dec 11, 2020
Synoposis: 
compares two numbers in the array to see which is bigger
*/
package finalds;
public class bubblecompare {
    public int comp(int[] a, int fir, int sec){
        int res=0;//1 means swap 2 mean no swap
        if(a[fir]>a[sec]){
            return 1;
        }
        return res;
    }
}
