/*
project name: finalds
program: bubblepass
Author: Erik Bailey
Date: Dec 11, 2020
Synoposis: 
goes through one pass of the array, comparing and sorting
*/
package finalds;
import java.util.Arrays;
public class bubblepass{
    public int[] pass2(int[] a,int ii,int count){
        bubblecompare c = new bubblecompare();
        bubbleswap s = new bubbleswap();
        int len =a.length-2;//-2 because last 2 are ii and count
        int res=0;//used to tell if swap 
        for(int i = ii; i<len-1;i++){//
            res=c.comp(a, i, i+1);
            if(res==1){
                a=s.swap(a, i, i+1);
                count++;
                a[len+1]=count;
                return a;
            }
            ii++;
            a[len]=ii;
        }
        if(count>0){
            return pass2(a,ii,count);
        }
        a[len]=-1;
        a[len+1]=-1;
        return a;
    }
}