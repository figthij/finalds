/*
project name: FinalDS
program:timer
Author: Erik Bailey
Date: Dec 7, 2020
Synoposis: makes a timer
*/
package finalds;
import java.awt.AWTException;
import java.awt.Robot;
import java.util.Scanner;
import java.util.Timer;
import javax.swing.JFrame;
import javax.swing.JLabel;
public class timer extends JFrame {
    JLabel jlabClock;
    timernumbers n;
    public timer() throws AWTException {
        OutputClass test = new OutputClass();
        int stop=1;
        String title="timer";
        Scanner sc=new Scanner(System.in);
        Robot rob=new Robot();
        while(stop!=0){
            test.printScreen(title);
            System.out.println("Select the time interval in seconds for the timer to go up to");
            System.out.println("Or type 0 to go back to the main menu");
            stop=sc.nextInt();
            if(stop!=0){
                n=new timernumbers(this,stop);
            }
            rob.delay(1000);
            refresh.clear(rob,100);
        }
    }
     public static void main(String[] args) throws InterruptedException { 
        new Timer();
    }
   
}
