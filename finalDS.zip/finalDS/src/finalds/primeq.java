/*
project name: FinalDS
program:primeq
Author: Erik Bailey
Date: Dec 7 2020
Synoposis: 
the queue used takes out the first value in it as it is prime and sends it to multiples to eliminate non prime numbers
*/
package finalds;
import java.util.LinkedList;
import java.util.Queue;
public class primeq {
    public Queue<Integer> ord(){
        Queue<Integer> order = new LinkedList<>();
        for(int x= 2; x<1000;x++){
            order.add(x);
        }
    return order;
    }
}
