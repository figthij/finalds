/*
project name: Finalds
program: compare
Author: Erik Bailey
Date: Dec 11, 2020
Synoposis: 
make three arrays with random numbers sort with 2 different sorts and compare efficiencies
*/
package finalds;
import java.awt.AWTException;
import java.awt.Robot;
import java.util.Scanner;
public class compare {
    public void main() throws AWTException {
        Scanner sc = new Scanner(System.in);
        String s="";     
        String title="compare";
        OutputClass test = new OutputClass();
        String exit="EXIT";
        while(s.matches(exit)==false){
            test.printScreen(title);
            bubblemakearr ma = new bubblemakearr();
            int size1=1000;
            int size2=100000;
            int size3=20000;
            int[] first = ma.arr(size1);
            int[] second = ma.arr(size2);
            int[] third = ma.arr(size3);
            int[] first2= new int[size1];
            int[] second2= new int[size2];
            int[] third2= new int[size3];
            System.arraycopy(first, 0, first2, 0, size1);
            System.arraycopy(second, 0, second2, 0, size2);
            System.arraycopy(third, 0, third2, 0, size3);
            comparetime t =new comparetime();
            t.stime(first, size1);
            t.btime(first2, size1);
            t.stime(second, size2);
            t.btime(second2, size2);
            t.stime(third, size3);
            t.btime(third2, size3);
            System.out.println("Type EXIT to go back");
            System.out.println("Type anything else to get another combination");
            s=sc.next();
            Robot rob=new Robot();
            refresh.clear(rob,500);
        }
    }
}
