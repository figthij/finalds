/*
project name: FinalDS
program:makearray
Author: Erik Bailey
Date: Dec 7, 2020
Synoposis: 
makes array with 1000 values
*/
package finalds;
import java.util.Arrays;
public class recurmakearray {
    public int[] yar(){//values 0 to 999 are 2 to 1001
        int yr[] = new int[1000];
        int yr15[] = new int[15];
        for(int i=0;i<yr.length;i++){
            yr[i]=i+2;
        }
        System.arraycopy(yr, 0, yr15, 0, 15);
        String s15=Arrays.toString(yr15);
        System.out.println("original "+s15);
        recurremove r = new recurremove();
        for(int i =0;i<=100;i++){
        r.rem(yr, i+2);
        }
        for(int i =100;i<yr.length;i++){
            yr[i]=0;
        }
        System.arraycopy(yr, 0, yr15, 0, 15);
        s15=Arrays.toString(yr15);
        System.out.println("new "+s15);
        return yr;
    }
}
