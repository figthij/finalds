/*
project name: finalds
program: bubblemakearr
Author: Erik Bailey
Date: Dec 11, 2020
Synoposis: 
makes array
*/
package finalds;
import java.util.Random;
public class bubblemakearr {
    public int[] arr(int size){
        int[] a = new int[size+2];
        for(int i=0;i<size+2;i++){
            inputnum(a,i);
        }
        return a;
    }
    public static void inputnum(int[] value,int i){
        Random rnum = new Random();
        value[i]=rnum.nextInt(100);
    }
}
