/*
project name: FinalDS
program:recursion
Author: Erik Bailey
Date: Dec 7, 2020
Synoposis: 
finds first 100 prime numbers using eratosthenes
must use recursion
should be able to only use one array
*/
package finalds;

import java.awt.AWTException;
import java.awt.Robot;
import java.util.Scanner;
public class recursion {
    public void main()throws AWTException {
        Scanner sc = new Scanner(System.in);
        String s="";     
        String title="recursion";
        OutputClass test = new OutputClass();
        String exit="EXIT";
        while(s.matches(exit)==false){
            test.printScreen(title);
            recurmakearray ma = new recurmakearray();
            ma.yar();
            System.out.println("Type EXIT to go back");
            System.out.println("Type anything else to repeat the process");
            s=sc.next();
            Robot rob=new Robot();
            refresh.clear(rob,500);
        }
    }
    
}
