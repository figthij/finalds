/*
project name: FinalDS
program:largest
Author: Erik Bailey
Date: Dec 7, 2020
Synoposis: 
Finds the largest number
*/
package finalds;
public class listlargest {
    public int largestinlist(int[] value, int size){
        int large=0;
        for(int i=0;i<size;i++){
            if(value[i]>large){
                large=value[i];
            }
        }
        return large;
    }
}
