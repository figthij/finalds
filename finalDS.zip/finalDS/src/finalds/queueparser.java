/*
project name: FinalDS
program:parser
Author: Erik Bailey
Date: Dec 7, 2020
Synoposis: 
parses various things used in queue
*/
package finalds;
import java.util.LinkedList;
import java.util.Queue;
public class queueparser {
    public Queue<String> charqueuetostringq(Queue<Character> symbol){
        Queue<String> str = new LinkedList<>();//
        String s="";
        int i;
        for(int x=symbol.size();x>0;x--){//merges intstack and symbol back into stack2
            i=symbol.remove();
            switch(i){
                    case '+':
                        s="+";
                        str.add(s);
                        break;
                    case '-':
                        s="-";
                        str.add(s);
                        break;
                    case '*':
                        s="*";
                        str.add(s);
                        break;
                    case '/':
                        s="/";
                        str.add(s);
                        break;
                    case '^':
                        s="^";
                        str.add(s);
                        break;
            }
        }
        return str;
    }        
    public Queue<String> queuetostringq(Queue<Integer> intstack){
        switches sw = new switches();
        Queue<String> str = new LinkedList<>();//
        String s="";
        int i;
        int g;
        for(int x=intstack.size();x>0;x--){//merges intstack and symbol back into stack2
            i=intstack.remove();
            g=i;
            if(i>=0){
                s="";
                while(g>=10)
                {
                    i=g;
                    i=i%10;
                    s=sw.posswitch(i)+s;
                    g=g-i;
                    g=g/10;
                }
                i=g;
                i=i%10;
                s=sw.posswitch(i)+s;
                g=g-i;
                g=g/10;
            }
            else if(i<0){
                g=i*-1;
                s="";
                while(g>=10)
                {
                    i=g;
                    i=i%10;
                    s=sw.posswitch(i)+s;
                    g=g-i;
                    g=g/10;
                }
                i=g;
                i=i%10;
                s=sw.posswitch(i)+s;
                s="-"+s;
                g=g-i;
                g=g/10;
            }
            str.add(s);
        }
        return str;
    }
    public Queue<Integer> stringtoint(Queue<String> str){
        Queue<Integer> nums2;
        nums2 = new LinkedList<>();
        switches sw = new switches();
        String s=" ";
        char ch;
        int ad=0;
        int place;
        int power;
        int intch;
        int i2;
        for(int x= str.size(); x>0;x--){
            s=str.remove();
            i2=s.length()-1;
            ad=0;
            for(int i=0;i<s.length();i++){
                ch=s.charAt(i);
                intch=sw.charswitch(ch);
                power=((int) Math.pow(10, i2));
                place=intch*power;
                ad=place+ad;
                i2--;
            }
            nums2.add(ad);
        }
        return nums2;
    }
    public Queue<Character> stringtoqueue(String expression){
        Queue<Character> stack = new LinkedList<>();
        for(int i =0; i<expression.length();i++){
            char c= expression.charAt(i);
            stack.add(c);
        }
        return stack;
    }
    public String inttostr(Queue<Integer> st,Queue<Integer> st2,int top,int tops){//needs to have one more number than symbol
        String s="";
        int t=top+tops;
        int n=0;
        int x=0;
        for(int i = 0; i<t;i++){
           if((i%2)==0){//checks if i is even when it is put a number
               x= st.remove();//dequeue
               switch(x){
                   case 0:
                       s=s+"0";
                       break;
                   case 1:
                       s=s+"1";
                       break;
                   case 2:
                       s=s+"2";
                       break;
                   case 3:
                       s=s+"3";
                       break;
                   case 4:
                       s=s+"4";
                       break;
                   case 5:
                       s=s+"5";
                       break;
                   case 6:
                       s=s+"6";
                       break;
                   case 7:
                       s=s+"7";
                       break;
                   case 8:
                       s=s+"8";
                       break;
                   case 9:
                       s=s+"9";
                       break;
               }
           }
           else if((i%2)!=0){
               x= st2.remove();
               switch(x){
                   case 0:
                       s=s+"+";
                       break;
                   case 1:
                       s=s+"-";
                       break;
                   case 2:
                       s=s+"*";
                       break;
                   case 3:
                       s=s+"/";
                       break;
                   case 4:
                       s=s+"^";
                       break;
                   case 5:
                       if(n==0){
                           s=s+"(";
                           n=1;
                       }
                       else if(n==1){
                           s=s+")";
                           n=0;
                       }
                       break;
               }
           }
        }
        if(n==1)
            s=s+")";
        return s;
    }
}
