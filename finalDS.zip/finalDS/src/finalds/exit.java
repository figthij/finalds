/*
project name: FinalDS
program:exit
Author: Erik Bailey
Date: Dec 7, 2020
Synoposis: 
displays an exit screen saying goodbye
*/
package finalds;
import java.awt.AWTException;
import java.awt.Robot;
public class exit {
    public void exit() throws AWTException{
        Robot rob=new Robot();
        refresh.clear(rob,500);
        String title="exit";
        OutputClass test = new OutputClass();
        test.printScreen(title);
        System.out.println("good bye");
        System.exit(0);
    }
}
