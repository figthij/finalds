/*
project name: FinalDS
program:endzero
Author: Erik Bailey
Date: Dec 7, 2020
Synoposis: 
puts values of zero at end of array
*/
package finalds;
public class recurendzero {
    public int[] back(int[] yr,int zeros){
        for(int i=0;i<yr.length;i++){
            if((yr[i]==0)&&(i<999)){
                yr[i]=yr[i+1];
                yr[i+1]=0;
            }
        }
        if(zeros>0){
            return back(yr,zeros-1);
        }
        return yr;
    }
}
