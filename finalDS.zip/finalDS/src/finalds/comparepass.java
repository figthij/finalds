/*
project name: Finalds
program: comparepass
Author: Erik Bailey
Date: Dec 11, 2020
Synoposis: 
goes through one pass of the array, comparing and sorting
*/
package finalds;
public class comparepass {
    public int[] bubble(int[] a){
        int count=1;
        compare2 c = new compare2();
        compareswap s = new compareswap();
        while(count>0){
            int len =a.length;
            int res=0;//used to tell if swap 
            count=0;
            for(int i = 0; i<len-1;i++){
                res=c.comp(a, i, i+1);
                if(res==1){
                    a=s.swap(a, i, i+1);
                    count++;
                }
            }
        }
        return a;
    }
    public int[] selection(int[] a){
        int size=a.length;
        compareswap s = new compareswap();
        int small=a[0];
        int sp=0;
        for(int i=0; i<size; i++){
            small=a[i];
            sp=i;
            for(int j=i+1;j<size; j++){
                if(small>a[j])
                {
                    small=a[j];
                    sp=j;
                }
            }
            a=s.swap(a, i, sp);
        }
        return a;
    }
}
