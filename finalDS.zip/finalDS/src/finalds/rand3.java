/*
project name: FinalDS
program:rand3
Author: Erik Bailey
Date: Dec 7, 2020
Synoposis: makes random numbers and finds out how many are divisible by 3
*/
package finalds;
import java.awt.AWTException;
import java.awt.Robot;
import java.util.Random;
import java.util.Scanner;
public class rand3 {
    public rand3() throws AWTException {
        Scanner sc = new Scanner(System.in);
        String s="";     
        String title="random 3";
        OutputClass test = new OutputClass();
        String exit="EXIT";
        randcalc3 calculate = new randcalc3();
        while(s.matches(exit)==false){
            test.printScreen(title);
            int[] value = new int[1000000];
            int i =0;
            while(i<1000000){
                inputnum(value,i);
                i=i+1;
            }
            calculate.calc(value);
            System.out.println("Type EXIT to go back");
            System.out.println("Type anything else to get another combination");
            s=sc.next();
            Robot rob=new Robot();
            refresh.clear(rob,500);
        }
    }
    public static void inputnum(int[] value,int i){
        Random rnum = new Random();
        value[i]=rnum.nextInt(1000);
    }
}
