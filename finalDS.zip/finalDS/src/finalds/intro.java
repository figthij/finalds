/*
project name: FinalDS
program:exit
Author: Erik Bailey
Date: Dec 7, 2020
Synoposis: 
displays an intro screen
*/
package finalds;
import java.awt.AWTException;
import java.awt.Robot;
import java.util.Scanner;
public class intro {
    public void intro() throws AWTException{
        Robot rob=new Robot();
        String title="intro";
        OutputClass test = new OutputClass();
        test.printScreen(title);
        Scanner sc=new Scanner(System.in);
        System.out.println("Hello type anything to start");
        sc.next();
        refresh.clear(rob,500);
    }
}
