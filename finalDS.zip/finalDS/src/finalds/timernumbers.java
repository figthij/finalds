/*
project name: FinalDS
program:numbers
Author: Erik Bailey
Date: Dec 7, 2020
Synoposis: 
shows time
*/
package finalds;
import java.awt.AWTException;
import java.awt.Robot;
public class timernumbers extends Thread{
    timer t;
    String tim;
    public timernumbers(timer t,int stop) throws AWTException{
        System.out.println("numbers");
        this.t = t;
        start();
        run(stop);
    }
    long startTime = System.currentTimeMillis();
    long timePassed = System.currentTimeMillis() - startTime;
    long secondsPassed = timePassed / 1000;
    long secondsShown = secondsPassed % 60;
    long minutes = secondsPassed / 60;
    String ti= String.valueOf(minutes);
    String i = String.valueOf(secondsShown);
    String m= ti+':'+i;
    String e = String.valueOf(timePassed);
    public void run(int stop) throws AWTException{
        int count=0;
        OutputClass test = new OutputClass();
        String title="timer";
        while(secondsPassed<stop){
            timePassed = System.currentTimeMillis() - startTime;
            secondsPassed = timePassed / 1000;
            secondsShown = secondsPassed % 60;
            minutes = secondsPassed / 60;
            ti= String.valueOf(minutes);
            i = String.valueOf(secondsShown);
            m= ti+':'+i;
            e = String.valueOf(timePassed);
            if(secondsPassed==count){
                Robot rob=new Robot();
                refresh.clear(rob,5);
                test.printScreen(title);
                System.out.println(minutes+":"+secondsShown);
                count=count+1;
            }
        }
    }
}
