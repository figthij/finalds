/*
project name: Finalds
program: compareswap
Author: Erik Bailey
Date: Dec 11, 2020
Synoposis: 
swaps two numbers in the array
*/
package finalds;
public class compareswap {
    public int[] swap(int[] a, int fir, int sec){
        int temp1=a[fir];
        int temp2=a[sec];
        a[sec]=temp1;
        a[fir]=temp2;
        return a;
    }
}