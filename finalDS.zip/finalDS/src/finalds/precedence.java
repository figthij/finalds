/*
project name: FinalDS
program:precedence
Author: Erik Bailey
Date: Dec 7, 2020
Synoposis: 
shows which symbol goes first
*/
package finalds;
public class precedence {
        public int precedence(char c){
        switch(c){
            case '+':
            case '-':
                return 1;
            case '*':
            case '/':
                return 2;
            case '^':
                return 3;
        }
        return -1;
    }
    public int precedences(String c){
        switch(c){
            case "+":
            case "-":
                return 1;
            case "*":
            case "/":
                return 2;
            case "^":
                return 3;
        }
        return -1;
    }
}
