/*
project name: FinalDS
program:prime100
Author: Erik Bailey
Date: Dec 7 2020
Synoposis: 
finds first 100 prime numbers using eratosthenes
must have stacks and a queue
*/
package finalds;
import java.awt.AWTException;
import java.awt.Robot;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;
import java.util.Stack;
public class prime100 {
    public prime100() throws AWTException {
        Scanner sc = new Scanner(System.in);
        String s="";     
        String title="prime";
        OutputClass test = new OutputClass();
        String exit="EXIT";
        while(s.matches(exit)==false){
            test.printScreen(title);
            primeq q= new primeq();
            prime p = new prime();
            primemultiples m = new primemultiples();
            primenon sea= new primenon();
            Stack<Integer> example = new Stack<>();//used for checking progress
            Queue<Integer> order = new LinkedList<>();
            order=q.ord();
            int prime=0;//takes next prime number from order 
            for(int i=0;i<15;i++){//changed 100 to 15 to fit in output display
                prime=p.prime(order);//takes next prime number from order
                example.add(prime);
                order=sea.search(m.multiply(prime), order);
            }
            System.out.println("first 15 primes"+example);
            System.out.println("Type EXIT to go back");
            System.out.println("Type anything else to repeat the process");
            s=sc.next();
            Robot rob=new Robot();
            refresh.clear(rob,500);
        }
    }
}