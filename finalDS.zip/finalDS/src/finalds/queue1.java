/*
project name: FinalDS
program:Queue1
Author: Erik Bailey
Date: Dec 7, 2020
Synoposis: 
sets up various queue basics to be used
*/
package finalds;
import java.util.LinkedList;
public class queue1<T> {
    private final LinkedList list;
    public queue1(){
        list=new LinkedList();
    }
    public boolean isEmpty(){
        return(list.isEmpty());
    }
    public void enqueue(Object item){
        list.add(item);
    }
    public Object dequeue(){
        Object item=list.get(1);
        list.remove(0);
        return item;
    }
    public Object peek(){
        return list.get(0);
    }
}
