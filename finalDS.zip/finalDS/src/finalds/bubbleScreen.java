/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalds;

/**
 *
 * @author Erik
 */
import java.awt.Color;
import java.awt.Graphics;
import java.util.Arrays;
import javax.swing.JPanel;
public class bubbleScreen extends JPanel {
    public bubbleScreen(){
        repaint();
    }
    public void paint(Graphics g){
        bubblemakearr ma=new bubblemakearr();
        bubblepass p = new bubblepass();
        int size=10;
        int[] a =ma.arr(size);
        String x= Arrays.toString(a);
//        System.out.println(x);
        int ii=0;
        int count=0;
        int[] order = new int[11];
        int s=0;
        for(int i=0;i<11;i++){
            order[i]=s;
            s=s+30;
        }
        a[size]=0;
        a[size+1]=0;
        p.pass2(a,ii,count);//sorts exerything
        g.setColor(Color.red);
        g.fillRect(0, 0, 300, 500);
        g.setColor(Color.BLACK);
        g.fillRect(0, 0, 300, 450);
        g.setColor(Color.BLUE);
        g.fillRect(0, 0, 300, 400);
        g.setColor(Color.CYAN);
        g.fillRect(0, 0, 300, 350);
        g.setColor(Color.DARK_GRAY);
        g.fillRect(0, 0, 300, 300);
        g.setColor(Color.GREEN);
        g.fillRect(0, 0, 300, 250);
        g.setColor(Color.ORANGE);
        g.fillRect(0, 0, 300, 200);
        g.setColor(Color.PINK);
        g.fillRect(0, 0, 300, 150);
        g.setColor(Color.YELLOW);
        g.fillRect(0, 0, 300, 100);
        g.setColor(Color.MAGENTA);
        g.fillRect(0, 0, 300, 50);
        int xa=10;
        for(int j=0;j<10;j++){
            g.setColor(new Color(100+xa, 50,150));
            xa=xa+10;
            g.fillRect(order[j], 500-(a[j]*5), 30, a[j]*5);
        }
        x= Arrays.toString(a);
//        System.out.println(x);
        p.pass2(a,ii,count);//sorts exerything
        g.setColor(Color.red);
        g.fillRect(325, 0, 300, 500);
        g.setColor(Color.BLACK);
        g.fillRect(325, 0, 300, 450);
        g.setColor(Color.BLUE);
        g.fillRect(325, 0, 300, 400);
        g.setColor(Color.CYAN);
        g.fillRect(325, 0, 300, 350);
        g.setColor(Color.DARK_GRAY);
        g.fillRect(325, 0, 300, 300);
        g.setColor(Color.GREEN);
        g.fillRect(325, 0, 300, 250);
        g.setColor(Color.ORANGE);
        g.fillRect(325, 0, 300, 200);
        g.setColor(Color.PINK);
        g.fillRect(325, 0, 300, 150);
        g.setColor(Color.YELLOW);
        g.fillRect(325, 0, 300, 100);
        g.setColor(Color.MAGENTA);
        g.fillRect(325, 0, 300, 50);
        xa=10;
        for(int j=0;j<10;j++){
            g.setColor(new Color(100+xa, 50,150));
            xa=xa+10;
            g.fillRect(order[j]+325, 500-(a[j]*5), 30, a[j]*5);
        }
        x= Arrays.toString(a);
//        System.out.println(x);
        p.pass2(a,ii,count);//sorts exerything
        g.setColor(Color.red);
        g.fillRect(650, 0, 300, 500);
        g.setColor(Color.BLACK);
        g.fillRect(650, 0, 300, 450);
        g.setColor(Color.BLUE);
        g.fillRect(650, 0, 300, 400);
        g.setColor(Color.CYAN);
        g.fillRect(650, 0, 300, 350);
        g.setColor(Color.DARK_GRAY);
        g.fillRect(650, 0, 300, 300);
        g.setColor(Color.GREEN);
        g.fillRect(650, 0, 300, 250);
        g.setColor(Color.ORANGE);
        g.fillRect(650, 0, 300, 200);
        g.setColor(Color.PINK);
        g.fillRect(650, 0, 300, 150);
        g.setColor(Color.YELLOW);
        g.fillRect(650, 0, 300, 100);
        g.setColor(Color.MAGENTA);
        g.fillRect(650, 0, 300, 50);
        xa=10;
        for(int j=0;j<10;j++){
            g.setColor(new Color(100+xa, 50,150));
            xa=xa+10;
            g.fillRect(order[j]+650, 500-(a[j]*5), 30, a[j]*5);
        }
        while(a[size]!=-1){
            x= Arrays.toString(a);
//            System.out.println(x);
            p.pass2(a,ii,count);//sorts exerything
            g.setColor(Color.red);
            g.fillRect(975, 0, 300, 500);
            g.setColor(Color.BLACK);
            g.fillRect(975, 0, 300, 450);
            g.setColor(Color.BLUE);
            g.fillRect(975, 0, 300, 400);
            g.setColor(Color.CYAN);
            g.fillRect(975, 0, 300, 350);
            g.setColor(Color.DARK_GRAY);
            g.fillRect(975, 0, 300, 300);
            g.setColor(Color.GREEN);
            g.fillRect(975, 0, 300, 250);
            g.setColor(Color.ORANGE);
            g.fillRect(975, 0, 300, 200);
            g.setColor(Color.PINK);
            g.fillRect(975, 0, 300, 150);
            g.setColor(Color.YELLOW);
            g.fillRect(975, 0, 300, 100);
            g.setColor(Color.MAGENTA);
            g.fillRect(975, 0, 300, 50);
            xa=10;
            for(int j=0;j<10;j++){
                g.setColor(new Color(100+xa, 50,150));
                xa=xa+10;
                g.fillRect(order[j]+975, 500-(a[j]*5), 30, a[j]*5);
            }
        }
    }
}
