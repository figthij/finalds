/*
project name: FinalDS
program:stackprime
Author: Erik Bailey
Date: Dec 7 2020
Synoposis: 
deals with the stack containing all the prime numbers
*/
package finalds;
import java.util.Stack;
public class stackprime {
    public Stack<Integer> primes(int prime,int times,Stack<Integer> p){
        if(times<100){
            p.add(prime);
        }
        return p;
    }
}
