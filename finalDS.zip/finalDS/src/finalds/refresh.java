/*
project name: FinalDS
program:refresh
Author: Erik Bailey
Date: Dec 7, 2020
Synoposis: refresh output screen
*/
package finalds;
import java.awt.Robot;
public class refresh { 
    public static void clear(Robot rob,int delay){
        rob.keyPress(17);
        rob.keyPress(76);
        rob.keyRelease(17);
        rob.keyRelease(76);
        rob.delay(delay);
    }
}
