/*
project name: FinalDS
program:nonprime
Author: Erik Bailey
Date: Dec 7 2020
Synoposis: 
searches for numbers to takke out
*/
package finalds;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;
public class primenon {
    public Queue<Integer> search(Stack<Integer> multiply,Queue<Integer> order){
        int out;
        int check;
        Queue<Integer> temp = new LinkedList();//used as a temp queue while checking
        for(int x=multiply.size();x>0;x--){//checks every case of multiply
            out=multiply.pop();
            for(int i=order.size();i>0;i--){//checks order and removes non prime numbers
                check=order.remove();
                if(out!=check){
                    temp.add(check);
                }
            }
            order=temp;
        }
        return order;
    }
}
