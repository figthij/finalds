/*
project name: FinalDS
program:multiply
Author: Erik Bailey
Date: Dec 7, 2020
Synoposis: 
determines what values to be removed
*/
package finalds;
public class recurmultiply {
    public int out(int multiplier, int times){
        int out;
        out=multiplier*times;
        return out;
    }
}
