/*
project name: finalds
program:class12ds
Author: Erik Bailey
Date: Dec 7, 2020
Synoposis: 
bubble sorts and writes result to file
*/
package finalds;
import java.awt.AWTException;
import java.awt.GridLayout;
import java.awt.Robot;
import java.io.IOException;
import java.util.Scanner;
import javax.swing.JFrame;
public class bubble extends JFrame {
    bubbleScreen s;
    public void bubble(){
      //  setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1550,550);
        setResizable(false);
        setTitle("Graphics");
        init();
    }
    public void init(){
        setLocationRelativeTo(null);
        setLayout(new GridLayout(1,1,0,0));
        bubbleScreen s=new bubbleScreen();
        add(s);
        setVisible(true);
    }
    public void main() throws IOException, AWTException {
        Scanner sc = new Scanner(System.in);
        String st="";     
        String title="bubble";
        OutputClass test = new OutputClass();
        String exit="EXIT";
        while(st.matches(exit)==false){
            test.printScreen(title);
            bubble b= new bubble();
            b.bubble();
            System.out.println("Type EXIT to go back");
            System.out.println("Type anything else to get another combination");
            st=sc.next();
            Robot rob=new Robot();
            refresh.clear(rob,500);
        }

 //       createFile cf = new createFile();
//        int[] a =ma.arr();//one extra value at end for keeping place 
      /*  
        String x= Arrays.toString(a);
        System.out.println("hiii "+x);
        coor c = new coor();
        c.file(x);//makes string
        x=p.pass(a,x);
        cf.openFile();
        cf.addRecord(x);
        cf.closeFile();
        sp.ScriptPython();
        
*/        
    }

}
