/*
project name: FinalDS
program:calc3
Author: Erik Bailey
Date: Dec 7, 2020
Synoposis: 
checks if numbers are divisable by 3
*/
package finalds;
public class randcalc3{ 
    public void calc(int number[]){
        int i =0;
        int x=0;
        int arraylength=number.length;
        while (i!=arraylength){//may need to fix to a better test
            int n = number[i];
            while (n>=0){
                if(n==0){
                    x=x+1;
                }
                n=n-3;
            }
            i=i+1;
        }
        System.out.println("out of "+ arraylength+ " numbers "+x+" are factors of three");
    }
}
