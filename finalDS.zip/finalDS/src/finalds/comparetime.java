/*
project name: Finalds
program: comparetime
Author: Erik Bailey
Date: Dec 11, 2020
Synoposis: 
times the process for each sort
*/
package finalds;
public class comparetime {
    public void stime(int[] sort, int amount){
        comparepass p = new comparepass();
        long startTime = System.currentTimeMillis();
        p.selection(sort);
        long endTime = System.currentTimeMillis();
        System.out.println("selection sort with "+ amount+" takes " + (endTime - startTime)+" to complete");        
    }
    public void btime(int[] sort, int amount){
        comparepass p = new comparepass();
        long startTime = System.currentTimeMillis();
        p.bubble(sort);
        long endTime = System.currentTimeMillis();
        System.out.println("bubble sort with "+ amount+" takes " + (endTime - startTime)+" to complete");        
    }
}
