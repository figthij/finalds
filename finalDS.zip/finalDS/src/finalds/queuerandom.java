/*
project name: FinalDS
program:random
Author: Erik Bailey
Date: Dec 7, 2020
Synoposis: 
chooses random numbers for queue
*/
package finalds;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;
public class queuerandom {
    public Queue<Integer> ran(int top){//makes random numbers between0 and 16
        Random num = new Random();
        int number;
        Queue<Integer> st=new LinkedList();
        number=num.nextInt(10);
        st.add(number);
        for(int i=2;i<top;i++){
            number=num.nextInt(10);
            st.add(number);
        }
        number=num.nextInt(10);
        st.add(number);
        return st;
    }
    public Queue<Integer> rans(int top){//makes random numbers between0 and 16
        Random num = new Random();
        int number;
        Queue<Integer> st=new LinkedList<>();
        number=num.nextInt(5);//put at 6 instead of 7 to close parenthesis
        st.add(number);
        for(int i=2;i<top;i++){
                number=num.nextInt(5);
                st.add(number);
        }
        number=num.nextInt(5);
        st.add(number);
        return st;
    }
}